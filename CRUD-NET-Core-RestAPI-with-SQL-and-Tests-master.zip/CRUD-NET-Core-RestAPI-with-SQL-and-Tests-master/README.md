# Basic CRUD NET Core RestAPI project with SQL and Integration and/or Unit Tests
<p> Hi there! </p>
<p> This project is my vision of a simple and basic Rest API project with SQL and Tests (Integration and/or Unit). </p>
<p> Since I don't have a lot of experience with NET Core, I am doing it for self-study and want to eventually get a stereotyped and templated project for newbie. </p>
<p> If you have any comments or suggestions - see you in Issues! </p>
<p> Thanks! </p>
