﻿namespace RestApi.Dtos
{
    public class UserForDeleteDto : UserForCreateDto { }
}
