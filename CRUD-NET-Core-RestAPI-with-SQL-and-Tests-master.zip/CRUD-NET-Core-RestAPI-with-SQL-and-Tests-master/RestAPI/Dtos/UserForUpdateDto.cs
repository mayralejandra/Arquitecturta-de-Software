﻿namespace RestApi.Dtos
{
    public class UserForUpdateDto : UserForCreateDto { }
}
